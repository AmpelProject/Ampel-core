#!/usr/bin/env python
# -*- coding: utf-8 -*-
# File              : ampel/logging/AmpelLoggingError.py
# License           : BSD-3-Clause
# Author            : vb <vbrinnel@physik.hu-berlin.de>
# Date              : 03.12.2018
# Last Modified Date: 18.01.2019
# Last Modified By  : vb <vbrinnel@physik.hu-berlin.de>

class AmpelLoggingError(Exception):
	pass
