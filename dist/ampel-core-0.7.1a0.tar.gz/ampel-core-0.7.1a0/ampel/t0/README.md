Brief T0 description here
