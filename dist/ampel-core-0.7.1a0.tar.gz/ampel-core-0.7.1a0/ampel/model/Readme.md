Package containing classes related to data validation and settings management using pydantic
