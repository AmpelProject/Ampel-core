# Package Description

Contains abstract classes that define abstract method.
The parent class - AmpelABC - enforces method signature.
Note that abstract classe not defining abstract methods
do exist in other package within the ampel system 
(ampel.t3.load.AbsT3Loader for example)
