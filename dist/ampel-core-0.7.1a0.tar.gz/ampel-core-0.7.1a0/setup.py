# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ampel',
 'ampel.abstract',
 'ampel.abstract.ingest',
 'ampel.aux',
 'ampel.aux.filter',
 'ampel.config',
 'ampel.config.builder',
 'ampel.config.collector',
 'ampel.core',
 'ampel.db',
 'ampel.db.query',
 'ampel.demo.unit.base',
 'ampel.dev',
 'ampel.ingest',
 'ampel.ingest.compile',
 'ampel.log',
 'ampel.log.handlers',
 'ampel.metrics',
 'ampel.model',
 'ampel.model.aux',
 'ampel.model.builder',
 'ampel.model.db',
 'ampel.model.ingest',
 'ampel.model.operator',
 'ampel.model.purge',
 'ampel.model.t3',
 'ampel.model.template',
 'ampel.model.time',
 'ampel.plot',
 'ampel.run',
 'ampel.t2',
 'ampel.t3',
 'ampel.t3.complement',
 'ampel.t3.context',
 'ampel.t3.load',
 'ampel.t3.run',
 'ampel.t3.run.filter',
 'ampel.t3.run.project',
 'ampel.t3.select',
 'ampel.test',
 'ampel.util',
 'ampel.vendor.aiopipe']

package_data = \
{'': ['*'], 'ampel': ['t0/*', 't1/*'], 'ampel.test': ['test-data/*']}

install_requires = \
['PyYAML>=5.4.1,<6.0.0',
 'ampel-interface>=0.7,<0.8',
 'prometheus-client>=0.9.0,<0.10.0',
 'psutil>=5.8.0,<6.0.0',
 'pydantic>=1.4,<1.5',
 'pymongo>=3.10,<4.0',
 'schedule>=1.0.0,<2.0.0',
 'sjcl>=0.2.1,<0.3.0',
 'slackclient>=2.7,<3.0',
 'yq>=2.12.0,<3.0.0']

extras_require = \
{'server': ['fastapi>=0.63.0,<0.64.0', 'uvicorn[standard]>=0.13.3,<0.14.0']}

entry_points = \
{'console_scripts': ['ampel-config = ampel.config.cli:main',
                     'ampel-controller = '
                     'ampel.core.AmpelController:AmpelController.main',
                     'ampel-db = ampel.db.AmpelDB:main']}

setup_kwargs = {
    'name': 'ampel-core',
    'version': '0.7.1a0',
    'description': 'Asynchronous and Modular Platform with Execution Layers',
    'long_description': None,
    'author': 'Valery Brinnel',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
