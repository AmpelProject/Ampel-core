Brief T1 description here
