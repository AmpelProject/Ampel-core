#!/usr/bin/env python
# -*- coding: utf-8 -*-
# File              : Ampel-core/ampel/ingest/StateT2Ingester.py
# License           : BSD-3-Clause
# Author            : vb <vbrinnel@physik.hu-berlin.de>
# Date              : 01.05.2020
# Last Modified Date: 01.05.2020
# Last Modified By  : vb <vbrinnel@physik.hu-berlin.de>

from ampel.abstract.ingest.AbsStateT2Ingester import AbsStateT2Ingester

class StateT2Ingester(AbsStateT2Ingester):
	""" To be implemented """
	pass
